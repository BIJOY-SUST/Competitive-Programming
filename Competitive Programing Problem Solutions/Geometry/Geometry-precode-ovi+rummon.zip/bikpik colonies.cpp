#include<bits/stdc++.h>
using namespace std;
#define EPS 1e-9
#define pi acos(-1.0)
int cmp(double x)
{
    if(fabs(x) < EPS) return 0;
    return x < 0 ? -1 : 1;
}
struct PT
{
    double x, y;
    PT()
    {
        x = y = 0;
    }
    PT(double _x, double _y)
    {
        x = _x, y = _y;
    }
    PT operator-(const PT &a) const
    {
        return PT(x - a.x, y - a.y);
    }
    PT operator+(const PT &a) const
    {
        return PT(x + a.x, y + a.y);
    }
    PT operator*(double a) const
    {
        return PT(x * a, y * a);
    }
    PT operator/(double a) const
    {
        return PT(x / a, y / a);
    }
    bool operator<(PT p) const
    {
        return x<p.x || (x==p.x && y<p.y);
    }
    double val()
    {
        return sqrt(x * x + y * y);
    }
    void scan()
    {
        scanf("%lf %lf", &x, &y);
    }
    void print()
    {
        printf("(%.4f, %.4f)", x, y);
    }
};
struct line
{
    double a, b, c;
};

double dist(PT a, PT b)
{
    return (a - b).val();
}

double dist2(PT a, PT b)
{
    a = a - b;
    return a.x * a.x + a.y * a.y;
}
double dot(PT a, PT b)
{
    return a.x * b.x + a.y * b.y;
}
double cross(PT a, PT b)
{
    return a.x * b.y - a.y * b.x;
}
PT RotateCCW90(PT p)
{
    return PT(-p.y,p.x);
}
PT RotateCW90(PT p)
{
    return PT(p.y,-p.x);
}
PT RotateCCW(PT p, double t)
{
    return PT(p.x*cos(t)-p.y*sin(t), p.x*sin(t)+p.y*cos(t));
}
PT RotateCW(PT p, double t)
{
    return PT(p.x*cos(t)+p.y*sin(t), -p.x*sin(t)+p.y*cos(t));
}

// project PT c onto line segment through a and b
PT ProjectPointSegment(PT a, PT b, PT c)
{
    double r = dot(b-a,b-a);
    if (fabs(r) < EPS) return a;
    r = dot(c-a, b-a)/r;
    if (r < 0) return a;
    if (r > 1) return b;
    return a + (b-a)*r;
}

// compute distance from c to segment between a and b
double DistancePointSegment(PT a, PT b, PT c)
{
    return sqrt(dist2(c, ProjectPointSegment(a, b, c)));
}
// returns bisector of angle YXZ
line bisector(PT Y, PT X, PT Z)
{
    PT xy = (Y - X)/(Y - X).val();
    PT xz = (Z - X)/(Z - X).val();
    PT d = xy + xz;
    line ret{d.y, -d.x, d.x * X.y - d.y * X.x};
    return ret;
}

struct point3
{
    double x, y, z;
    point3() {}
    point3(double _x, double _y, double _z)
    {
        x = _x, y = _y, z = _z;
    }
    point3 operator-(const point3 &a) const
    {
        return point3(x - a.x, y - a.y, z - a.z);
    }
    point3 operator+(const point3 &a) const
    {
        return point3(x + a.x, y + a.y, z + a.z);
    }
    point3 operator*(double a) const
    {
        return point3(x * a, y * a, z*a);
    }
    point3 operator/(double a) const
    {
        return point3(x / a, y / a, z/a);
    }
    double val()
    {
        return sqrt(x*x + y*y + z*z);
    }
    void scan()
    {
        scanf("%lf %lf %lf", &x, &y, &z);
    }
};


inline vector<PT> convex_hull(vector<PT> P)
{
    int n = P.size(), k = 0;
    vector<PT> H(2*n);
    sort(P.begin(), P.end());
    for(int i = 0; i<n; i++)
    {
        while(k>=2 && cmp(cross(H[k-2] - H[k-1], P[i] - H[k-1])) <= 0) k--;
        H[k++] = P[i];
    }
    for(int i = n-2, t = k+1; i>=0; i--)
    {
        while(k>=t && cmp(cross(H[k-2] - H[k-1], P[i] - H[k-1])) <= 0) k--;
        H[k++] = P[i];
    }
    H.resize(k-1);
    return H;
}


point3 cross3(point3 a, point3 b)
{
    return point3(a.y*b.z - a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x);
}

point3 rotatex(point3 a, double angle)
{
    double cosa = cos(angle), sina = sin(angle);
    double y = a.y * cosa - a.z * sina;
    double z = a.y * sina + a.z * cosa;
    double x = a.x;
    return point3(x, y, z);
}

point3 rotatey(point3 a, double angle)
{
    double cosa = cos(angle), sina = sin(angle);
    double z = a.z * cosa - a.x * sina;
    double x = a.z * sina + a.x * cosa;
    double y = a.y;
    return point3(x, y, z);
}

point3 rotatez(point3 a, double angle) // guess perfect
{
    double cosa = cos(angle), sina = sin(angle);
    double x = a.x * cosa - a.y * sina;
    double y = a.x * sina + a.y * cosa;
    double z = a.z;
    return point3(x, y, z);
}

double d;
double solve(vector<PT> vt)
{
    double peri = 0.0, area = 0.0;
    auto hull = convex_hull(vt);
    int n = hull.size();
    for(int i = 0; i<n; i++)
    {
        int a = i;
        int b = (i + 1) % n;
        peri += dist(hull[a], hull[b]);
        area += hull[a].x * hull[b].y - hull[a].y * hull[b].x;
    }
    area = fabs(area/2.0);
    return area * 2.0+ pi * d * peri + 4 * pi * d * d;
}

vector<PT> vt;
int n;
double dp2[(1<<13)];
int vis2[(1<<13)],cas;
double cal(int mask)
{
    if(mask==0)return 0;
    if(vis2[mask]==cas)return dp2[mask];
    vis2[mask]=cas;
    vector<PT> nw;
    for(int i = 0; i<n; i++)
    {
        if(mask & (1<<i)) nw.push_back(vt[i]);
    }
    return dp2[mask]=solve(nw);
}
const double big = 1000000000000000000.0;
double dp3[1<<13];
double dp_func2(int n)
{

    dp3[0]=0;
    for(int i=1; i<(1<<n); i++)
    {
        dp3[i]=cal(i);
        double dim=dp3[i],tp;

        for(int j=i;; j=(j-1)&i)
        {
            if(i==j) continue;
            if(j==0)break;
            tp=dp3[j]+dp3[i^j];
            dim=min(dim,tp);
        }
        // cout<<i<<endl;
        dp3[i]=dim;
    }

    return dp3[(1<<n)-1];

}

double dot3(point3 a, point3 b)
{
    return a.x * b.x + a.y * b.y + a.z * b.z;
}
int main()
{
//    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
    int t, tst = 1;
    cas = 0;
    scanf("%d", &t);
    while(t--)
    {
        cas++;
        scanf("%d %lf", &n, &d);
//        assert(n>0);
        vector<point3> ara = vector<point3>(n);
        point3 norm(0, 1, 0);
        for(int i = 0; i<n; i++)
            ara[i].scan();
        vt = vector<PT>(n);
        int f = 0;
        for(int i = 2; i<n; i++)
        {
            if(cmp(cross3(ara[1] - ara[0], ara[i] - ara[0]).val()) != 0)
            {
                norm = cross3(ara[1] - ara[0], ara[i] - ara[0]);
                norm = norm / norm.val();
                f = 1;
                break;
            }
        }
        if(!f)
        {
            if(n>1)
            {
                norm = ara[1] - ara[0];
                if(cmp(norm.x) != 0)
                {
                    norm = point3(-(norm.y + norm.z) / norm.x, 1, 1);
                }
                else if(cmp(norm.y) != 0)
                {
                    norm = point3(1, -(norm.x + norm.z) / norm.y, 1);
                }
                else if(cmp(norm.z) != 0)
                {
                    norm = point3(1, 1, -(norm.y + norm.x) / norm.z);
                }
//                    assert(cmp(norm.val()));
                norm = norm / norm.val();
            }
        }
        cout<<setprecision(20);
        point3 prvNorm = norm;
        double anglez = atan2(norm.y, norm.z);
//        cout << norm.x << " - " << norm.y << " - " << norm.z << endl;
//        cout << anglez  << " ***" << endl;
        norm = rotatex(norm, anglez);
//        cout << norm.x << " - " << norm.y << " - " << norm.z << endl;
        double anglez2 = -atan2(norm.x, norm.z);
        norm = rotatey(norm, anglez2);
//        cout << norm.x << " - " << norm.y << " - " << norm.z << endl;
//        cout << acos(norm.z)  << " ***" << endl;
//        assert(cmp(fabs(norm.z) - 1)==0);
//        assert(cmp(norm.x)==0);
//        assert(cmp(norm.y)==0);
        double allz = 0;
        point3 xx = ara[0];
        for(int i = 0; i<n; i++)
        {
            assert(cmp(dot3(ara[i] - xx, prvNorm)) == 0);
            ara[i] = rotatex(ara[i], anglez);
            ara[i] = rotatey(ara[i], anglez2);
//                printf("%.3f %.3f %.3f\n", ara[i].x, ara[i].y, ara[i].z);
            vt[i] = PT(ara[i].x, ara[i].y);
            if(i==0) allz = ara[i].z;
            else
            {
//                assert(cmp(fabs(allz) - fabs(ara[i].z)) == 0);
            }
        }
        double ans = dp_func2(n);
        printf("%.14f\n", ans);
    }
    return 0;
}
