#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstdlib>

using namespace std;

int main(){
    int n,m;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>m;
        int a[1000];
        for(int j=0;j<m;j++){
            cin>>a[j];
        }
        sort(a,a+m);
        int  gcd=1;
        for(int i=0;i<m-1;i++){
            for(int k=i+1;k<m;k++){
            for(int j=2;j<=a[i]&&j<=a[k];j++){
            if(a[i]%j==0 && a[k]%j == 0){
            if(j>gcd){
                gcd = j;
            }
            }
            }
        }
        }
        cout<<gcd<<endl;
    }

    return 0;
}