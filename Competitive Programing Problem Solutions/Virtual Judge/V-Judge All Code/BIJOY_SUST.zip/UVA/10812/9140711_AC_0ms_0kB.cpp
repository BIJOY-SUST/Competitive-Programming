#include<bits/stdc++.h>
using namespace std;
int main(){
    int a,b,T,x,y,i=1;
    cin>>T;
    while(i<=T){
        cin>>a>>b;
        if(a>=b&&(a+b)%2==0){
            x = ((a+b)/2);
            y = ((a-b)/2);
            cout<<x<<" "<<y<<endl;
        }
        else{
            cout<<"impossible"<<endl;
        }
        i++;
    }
    return 0;
}
