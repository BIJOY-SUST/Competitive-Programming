#include<bits/stdc++.h>
using namespace std;
int main(){
    int a,b,T;
    cin>>T;
    for(int i=0;i<T;i++){
        int x,y;
        cin>>a>>b;
        if(a<=0||b<=0){
            cout<<"impossible"<<endl;
        }
        else if(a>b){
            x = (a+b)/2;
            y = (a-b)/2;
            if(x>y)
                cout<<x<<" "<<y<<endl;
            else
                cout<<y<<" "<<x<<endl;
        }
        else{
            cout<<"impossible"<<endl;
        }
    }
    return 0;
}