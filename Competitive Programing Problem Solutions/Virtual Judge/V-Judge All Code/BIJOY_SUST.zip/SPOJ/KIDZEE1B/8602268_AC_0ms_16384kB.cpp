#include<stdio.h>

int main()

{

     int T, i, x, y, z, sum,n=1;

     scanf("%d",&T);

     for(i = 1; i <= T; i++)

     {
           scanf("%d %d %d", &x,&y,&z);
           sum = x+y+z;
           printf("Case %d: Sum of %d, %d and %d is %d\n", n,x,y,z,sum);
          n++;
      }

return 0;

}