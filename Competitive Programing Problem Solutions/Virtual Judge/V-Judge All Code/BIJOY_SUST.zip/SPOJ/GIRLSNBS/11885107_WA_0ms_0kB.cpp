#include<bits/stdc++.h>
//#define mx             100001
//#define mod            1000000007
//#define pi             2*acos(0.0)
//#define p              pair<int,int>
//#define ll             long long int
//#define one(n)         _builtin_popcount(n)
//#define ull            unsigned long long int
//#define valid(tx,ty)   tx>=0&&tx<r&&ty>=0&&ty<c
//const int fx[]={+1,-1,+0,+0};
//const int fy[]={+0,+0,+1,-1};
//const int fx[]={+0,+0,+1,-1,-1,+1,-1,+1};
//const int fy[]={-1,+1,+0,+0,+1,+1,-1,-1};
//const int fx[]={-2,-2,-1,-1,+1,+1,+2,+2};
//const int fy[]={-1,+1,-2,+2,-2,+2,-1,+1};
//int biton(int n,int pos){return n=n|(1<<pos);}
//int bitoff(int n,int pos){return n=n&~(1<<pos);}
//bool check(int n,int pos){return (bool)(n&(1<<pos));}
using namespace std;

int main(){
//    freopen("Input.txt","r",stdin);
//    freopen("Output.txt","w",stdout);
    int g,b;
    while(scanf("%d %d",&g,&b)==2){
        if(g==-1&&b==-1) break;
        if(g==b){
            printf("1\n");
        }
        else if(g==0){
            printf("%d\n",b);
        }
        else if(b==0){
            printf("%d\n",g);
        }
        else if(g>b){
            int ans=(g+b)/(b+1);
            printf("%d\n",ans);
        }
        else if(g<b){
            int ans=(g+b)/(g+1);
            printf("%d\n",ans);
        }
    }
    return 0;
}
/*

*/
