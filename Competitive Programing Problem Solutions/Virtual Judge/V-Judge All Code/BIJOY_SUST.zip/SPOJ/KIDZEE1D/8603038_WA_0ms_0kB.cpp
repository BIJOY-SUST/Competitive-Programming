#include<stdio.h>

int main()

{

    int i,T,M;
    scanf("%d",&T);

    for(i = 1; i <=T; i++)
    {
        scanf("%d",&M);
        if(M>=80&&M<=100){
            printf("A+\n");
        }
        else if(M>=75&&M<=79){
            printf("A\n");
        }
        else if(M>=70&&M<=74){
            printf("A-\n");
        }
        else if(M>=65&&M<=69){
            printf("B+\n");
        }
        else if(M>=60&&M<=64){
            printf("B\n");
        }
        else if(M>=55&&M<=59){
            printf("B-\n");
        }
        else if(M>=50&&M<=54){
            printf("C\n");
        }
        else if(M>=45&&M<=49){
            printf("D\n");
        }
        else{
            printf("F\n");
        }
    }
    return 0;

}