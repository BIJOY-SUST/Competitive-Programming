#include<stdio.h>
int main(){
    int i,len1, len2;
    char a[10],b[10];
    while(scanf("%s %s",&a,&b)){
        len1 = strlen(a);
        len2 = strlen(b);
        if(len1!=4||len2!=4){
            break;
        }
        if(a[3]%2==0&&b[3]%2!=0){
            printf("yes\n");
        }
        else{
            printf("no\n");
        }
    }
    return 0;
}