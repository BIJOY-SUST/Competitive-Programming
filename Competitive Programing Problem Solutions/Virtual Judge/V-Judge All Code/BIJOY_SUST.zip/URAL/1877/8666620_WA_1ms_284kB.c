#include<stdio.h>
int main(){
    int i,len1, len2;
    char a[10],b[10];
    scanf("%s %s",&a,&b);
        if(a[3]%2==0&&b[3]%2==1){
            printf("yes\n");
        }
        else{
            printf("no\n");
        }
    return 0;
}