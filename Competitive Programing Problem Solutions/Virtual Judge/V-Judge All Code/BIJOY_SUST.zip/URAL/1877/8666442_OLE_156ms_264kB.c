#include<stdio.h>
int main(){
    int i;
    char a[10],b[10];
    while(scanf("%s %s",&a,&b)){

        if(a[3]%2==0&&b[3]%2!=0){
            printf("yes\n");
        }
        else{
            printf("no\n");
        }
    }
    return 0;
}