#include<stdio.h>
int main(){
    long long int N,i,sum;
    while(scanf("%lld",&N)){
        sum = 0;
        if(N>0){
            for(i=1;i<=N;i++){
                sum = sum + i;
            }
        }
        else if(N<0){
            for(i=1;i>=N;i--){
                sum = sum + i;
            }
        }
        printf("%lld\n",sum);
    }
}