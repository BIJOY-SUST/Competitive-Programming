#include<stdio.h>
int main(){
    signed int N,i,sum;
    while(scanf("%d",&N)){
        sum = 0;
        if(N>0){
            for(i=1;i<=N;i++){
                sum = sum + i;
            }
        }
        else if(N<0){
            for(i=1;i>=N;i--){
                sum = sum + i;
            }
        }
        printf("%d\n",sum);
    }
}