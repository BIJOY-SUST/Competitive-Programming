#include<stdio.h>
int main(){
    long long int n,k,fact,len;

    while(scanf("%lld",&n)==1){
        scanf("%lld",&k);
        fact = n;

        while(n>1){
            n = n-k;
            fact = fact*n;
        }
        printf("%lld\n",fact);
    }
}