#include<stdio.h>
#include<string.h>
int main(){
    int n,k,fact,len;
    char ara[25];

    scanf("%d",&n);
    scanf("%s",ara);
    len = strlen(ara);
    fact = n;

    while(n>1){
        n = n-len;
        fact = fact*n;
    }
    printf("%d\n",fact);
}