include<stdio.h>
#include<string.h>
int main(){
    long long int n,k,fact,len;
    char ara[25];

    scanf("%lld",&n);
    scanf("%s",&ara);
    len = strlen(ara);
    fact = n;

    while(n>1){
        n = n-len;
        fact = fact*n;
    }
    printf("%lld\n",fact);
}