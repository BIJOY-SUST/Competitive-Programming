#include<stdio.h>
#include<string.h>
int main(){
    int n,fact,len;
    char k[25];

    scanf("%d",&n);
    scanf("%s",k);
    len = strlen(k);
    fact = n;

    while(n>1){
        n = n-len;
        fact = fact*n;
    }
    printf("%d\n",fact);
}