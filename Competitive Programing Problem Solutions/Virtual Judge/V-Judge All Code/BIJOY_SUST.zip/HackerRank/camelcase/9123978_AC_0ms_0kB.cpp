#include<bits/stdc++.h>
using namespace std;
int main ()
{
  int i=0,k = 1;
  string str;
  cin>>str;
  char c;
  while (str[i])
  {
    c=str[i];
    if (isupper(c)) k++;
    i++;
  }
  cout<<k<<endl;
  return 0;
}
