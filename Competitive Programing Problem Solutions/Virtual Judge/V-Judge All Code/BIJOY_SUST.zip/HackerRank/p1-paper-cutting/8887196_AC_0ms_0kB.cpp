#include<bits/stdc++.h>

using namespace std;
int main(){
    long long n,m;
    while(cin>>n>>m){
        long long  s = n*m-1;
        cout<<s<<endl;
    }
    return 0;
}