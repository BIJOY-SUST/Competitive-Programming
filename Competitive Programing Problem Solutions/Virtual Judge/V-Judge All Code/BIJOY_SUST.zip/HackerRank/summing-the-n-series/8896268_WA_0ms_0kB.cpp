#include<bits/stdc++.h>

using namespace std;
int main() {
    long long int T, n, res;
    cin>>T;
    while(T--){
        res=0;
        cin>>n;
        for(int i=1;i<=n;i++){
            res = (n*n)%1000000007;
        }
        cout<<res<<endl;
    }
    return 0;
}