#include<bits/stdc++.h>

using namespace std;
int main() {
    unsigned long long int T, n, res;
    cin>>T;
    while(T--){
        res=0;
        cin>>n;
        n = n%1000000007;
        res = (n*n)%1000000007;
        cout<<res<<endl;
    }
    return 0;
}