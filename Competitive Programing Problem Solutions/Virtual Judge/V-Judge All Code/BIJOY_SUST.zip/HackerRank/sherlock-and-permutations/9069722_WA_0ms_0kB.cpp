#include<bits/stdc++.h>
#define p 1000000007
using namespace std;

unsigned long long int fact(unsigned long long int t){
    unsigned long long int i,temp=1;
    for(i=1;i<=t;i++){
        temp=((temp*i)%p);
    }
    return temp;
}
int main(){
    int t,i;
    cin>>t;
    unsigned long long int temp,n,m;
    for(i=0;i<t;i++){
        cin>>n>>m;
        m=m-1;
        temp = ((fact(n+m)%p)/((fact(n)%p)*(fact(m)%p)))%p;
        cout<<temp<<endl;
    }
    return 0;
}