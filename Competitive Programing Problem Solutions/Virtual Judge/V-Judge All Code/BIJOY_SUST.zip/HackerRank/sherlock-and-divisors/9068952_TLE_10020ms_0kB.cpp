#include<bits/stdc++.h>
using namespace std;
int main(){
    long long int T,N;
    cin>>T;
    while(T--){
        long long int i, c=0;
        cin>>N;
        for(i=2;i<=N;i+=2){
            if(N%i==0){
                c++;
            }
        }
        cout<<c<<endl;
    }
    return 0;
}