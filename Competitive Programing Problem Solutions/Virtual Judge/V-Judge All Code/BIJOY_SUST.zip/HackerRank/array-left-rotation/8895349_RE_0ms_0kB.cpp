#include<bits/stdc++.h>

using namespace std;
int main(){
    long int n,d;
    int a[100];
    cin>>n>>d;
    for(long int i=0;i<n;i++){
        cin>>a[i];
    }
    for(long int i=0;i<d;i++){
        long int swap = a[0];
        long int j;
        for(j=0;j<n-1;j++){
            a[j] = a[j+1];
        }
        a[j] = swap;
    }
    long int i;
    for(i=0;i<n-1;i++){
        cout<<a[i]<<" ";
    }
    cout<<a[i]<<endl;

    return 0;
}