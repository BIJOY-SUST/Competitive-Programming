#include<bits/stdc++.h>
using namespace std;
int main(){
    int T,N;
    cin>>T;
    while(T--){
        cin>>N;
        int ans = N*(N-1)+1;
        cout<<ans<<endl;
    }
    return 0;
}