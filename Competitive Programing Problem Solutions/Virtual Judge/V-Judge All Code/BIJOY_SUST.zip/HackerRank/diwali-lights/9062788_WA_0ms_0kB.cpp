#include<bits/stdc++.h>
using namespace std;
int main(){
    long long T,N;
    cin>>T;
    while(T--){
        cin>>N;
        long long ans = N*(N-1)+1;
        cout<<ans<<endl;
    }
    return 0;
}