#include<bits/stdc++.h>
using namespace std;
int main(){
    long long int T,N;
    cin>>T;
    while(T--){
        cin>>N;
        long long int ans = pow(2,N)-1;//ketab uddin 128 page..............
        cout<<ans<<endl;
    }
    return 0;
}