#include<bits/stdc++.h>
using namespace std;
int main(){
    int T;
    cin>>T;;
    while(T--){
        int N;
        cin>>N;
        long long int ans = pow(2,N)-1;/*ketab uddin 128 page....*/
        cout<<ans<<endl;
    }
    return 0;
}