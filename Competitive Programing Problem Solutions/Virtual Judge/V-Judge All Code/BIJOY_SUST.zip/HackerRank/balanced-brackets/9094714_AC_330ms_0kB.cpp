#include<bits/stdc++.h>
using namespace std;
string prove(string ss){
    stack<char>s;
    for(int i=0;i<ss.size();i++){
        char c = ss[i];
        switch(c){
            case '[':
            case '{':
            case '(':
                s.push(c);
                break;
            case ')':
                if(s.empty()||s.top() != '('){
                    return "NO";
                }
                s.pop();
                break;
            case '}':
                if(s.empty()||s.top()!='{'){
                   return "NO";
                }
                s.pop();
                break;
            case ']':
                if(s.empty()||s.top()!='['){
                    return "NO";
                }
                s.pop();
                break;
        }
    }
    if(s.empty()){
        return "YES";
    }
    else{
        return "NO";
    }
}
int main(){
    int T;
    cin>>T;
    while(T--){
        string s;
        cin>>s;
        cout<<prove(s)<<endl;
    }
    return 0;
}