#include<stdio.h>
#include<string.h>
int main(){
    int len,n;
    char str[25];
    gets(str);
    len = strlen(str);
    n = 26+(25*len);
    printf("%d\n",n);
}