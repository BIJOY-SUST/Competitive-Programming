#include<bits/stdc++.h>
using namespace std;
int main(){
    int x1,x2,y1,y2,x3,x4,y3,y4;
    while(cin>>x1>>y1>>x2>>y2){
        if(y1==y2&&x1!=x2){
            x3=x2;
            y3=y2+abs(x2-x1);
            x4=x1;
            y4=y2+abs(x2-x1);
            cout<<x3<<" "<<y3<<" "<<x4<<" "<<y4<<"\n";
        }
        else if(x1==x2&&y1!=y2){
            y3=y2;
            x3=x2+abs(y2-y1);
            y4=y1;
            x4=x2+abs(y2-y1);
            cout<<x3<<" "<<y3<<" "<<x4<<" "<<y4<<"\n";
        }
        else if(abs(x2-x1)==abs(y2-y1)){
            x3=x2;
            y3=y1;
            x4=x1;
            y4=y2;
            cout<<x3<<" "<<y3<<" "<<x4<<" "<<y4<<"\n";
        }
        else{
            cout<<-1<<"\n";
        }
    }
    return 0;
}
