#include<bits/stdc++.h>
#define max 1000000001
using namespace std;
long long int a[max];
int main(){
   long long int n,c=0;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    sort(a,a+n);
    for(int i=0;i<n-1;i++){
        if(a[i+1]>a[i]){
            c++;
        }
    }
    cout<<c<<endl;
    return 0;

}