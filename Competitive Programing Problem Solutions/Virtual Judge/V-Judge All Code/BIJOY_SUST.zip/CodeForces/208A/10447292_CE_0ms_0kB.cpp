#include<stdio.h>
int main()
{
char a[200],b[200];
gets(a);
int i,j=0,k=0;
int len=strlen(a);
for(i=0;i<len;i++){
if(a[i]==’W’ && a[i+1]==’U’ && a[i+2]==’B’){
i+=2;
k=1;
}
else{
if(k==1 && j>0){
b[j]=’ ‘;
j++;
}
b[j]=a[i];
k=2;
j++;
}
}
b[j]=’\0’;
puts(b);
return 0;
}