#include<bits/stdc++.h>
using namespace std;
int main(){
    string s;
    string p;
    char dot = '.';
    getline(cin,s);
    int len = s.size();
    int i,j=0;
    for(i=0;i<len;i++){
        if(s[i]=='A' || s[i]=='a');
        else if(s[i]=='E' || s[i]=='e');
        else if(s[i]=='I' || s[i]=='i');
        else if(s[i]=='O' || s[i]=='o');
        else if(s[i]=='U' || s[i]=='u');
        else if(s[i]=='Y' || s[i]=='y');
        else if(s[i]>=65 && s[i]<=90){
            s[i]=s[i]+32;
            p=p+dot+s[i];
        }
        else{
            p=p+dot+s[i];
        }
    }
    cout<<p<<endl;
    return 0;
}
