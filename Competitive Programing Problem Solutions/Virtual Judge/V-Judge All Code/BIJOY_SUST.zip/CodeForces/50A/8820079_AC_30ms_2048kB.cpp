#include<cstdio>
#include<iostream>

using namespace std;

int main()
{
    int M,N;
    cin >> M >> N;
    int ans=(M*N)/(2*1);
    cout<<ans<<endl;
    return 0;
}