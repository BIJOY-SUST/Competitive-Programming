#include<bits/stdc++.h>
//#define pi             2*acos(0.0)
//#define valid(tx,ty)   tx>=0&&tx<r&&ty>=0&&ty<c
//#define p              pair<int,int>
//#define ll             long long int
//#define llu            unsigned long long int
#define mx             100005
//#define mod            100000007
//const long long inf =  1e15;
//----------------------Graph Moves--------------------
//const int fx[]={+1,-1,+0,+0};
//const int fy[]={+0,+0,+1,-1};
//const int fx[]={+0,+0,+1,-1,-1,+1,-1,+1};
//const int fy[]={-1,+1,+0,+0,+1,+1,-1,-1};
//const int fx[]={-2,-2,-1,-1,+1,+1,+2,+2};
//const int fy[]={-1,+1,-2,+2,-2,+2,-1,+1};
//-----------------------------------------------------
//-----------------------Bitmask-----------------------
//int biton(int n,int pos){return n=n|(1<<pos);}
//int bitoff(int n,int pos){return n=n&~(1<<pos);}
//bool check(int n,int pos){return (bool)(n&(1<<pos));}
//-----------------------------------------------------
using namespace std;
int n,e;
vector<int>edges[mx];
map<int,bool>visited;
bool DFS(int vertex,int parent){
    visited[vertex]=true;
    for(int i=0;i<edges[vertex].size();i++){
        int c=edges[vertex][i];
        if(!visited[c]){
            if(DFS(c,vertex)){
                return true;
            }
        }
        else if(c!=parent){
            return true;
        }
    }
    return false;
}
void isCyclic(){
    for(int i=0;i<n;i++){
        visited[i]=false;
    }
    int ans1=0,ans=0;
    for(int i=0;i<n;i++){
        if(!visited[i]){
            ans=1;
            if(DFS(i,-1)){
                ans=0;
            }
            ans1=ans1+ans;
        }
    }
    printf("%d\n",ans1-1);
}
int main(){
//    freopen("Input.txt","r",stdin);
//    freopen("Output.txt","w",stdout);
    scanf("%d %d",&n,&e);
    for(int i=1;i<=e;i++){
        int u,v;
        scanf("%d %d",&u,&v);
        edges[u].push_back(v);
        edges[v].push_back(u);
    }
    isCyclic();
    return 0;
}
/*
Input
4 3
2 1
1 3
4 3
Output
1
Input
5 5
2 1
1 3
2 3
2 5
4 3
Output
0
Input
6 5
1 2
2 3
4 5
4 6
5 6
Output
1
10 10
1 2
2 5
3 5
2 3
3 4
6 7
7 8
8 9
7 9
9 10
*/

