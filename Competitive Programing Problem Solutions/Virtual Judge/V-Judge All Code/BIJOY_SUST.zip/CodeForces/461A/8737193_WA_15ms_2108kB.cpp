#include<cstdio>
#include<algorithm>
#include<iostream>

using namespace std;

long long i,n,a[10000];
int main(){
    long long sum = 0;
    cin>>n;
    for(i=0;i<n;i++){
        scanf("%lld",&a[i]);
    }
    sort(a,a+n);
    for(i=0;i<n-1;i++){
        sum = sum +a[i]*(i+2);
    }
    sum = sum + a[n-1]*n;
    cout<<sum;
    return 0;
}