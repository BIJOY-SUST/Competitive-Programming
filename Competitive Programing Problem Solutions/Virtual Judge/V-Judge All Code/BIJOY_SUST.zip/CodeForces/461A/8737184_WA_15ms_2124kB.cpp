#include<cstdio>
#include<algorithm>
#include<iostream>

using namespace std;

long long i,n,sum=0,a[10000];
int main(){
    cin>>n;
    for(i=0;i<n;i++){
        scanf("%lld",&a[i]);
    }
    sort(a,a+n);
    for(i=0;i<n-1;i++)
    sum = sum +a[i]*(i+2);
    sum = sum + a[n-1]*n;
    cout<<sum;
    return 0;
}