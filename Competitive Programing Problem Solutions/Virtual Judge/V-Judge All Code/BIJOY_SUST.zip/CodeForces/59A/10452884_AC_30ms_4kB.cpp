#include<bits/stdc++.h>
using namespace std;
int main(){
    string s;
    cin>>s;
    int c=0,l;
    l=s.length();
    for(int i=0;i<l;i++){
        if(isupper(s[i])) c++;
    }
    if(c>l-c){
        for(int j=0;j<l;j++){
            char ch=toupper(s[j]);
            printf("%c",ch);
        }
    }
    else{
        for(int j=0;j<l;j++){
            char ch=tolower(s[j]);
            printf("%c",ch);
        }
    }
    return 0;
}
