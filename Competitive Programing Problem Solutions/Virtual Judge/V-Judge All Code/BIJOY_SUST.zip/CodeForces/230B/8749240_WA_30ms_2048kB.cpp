#include<cstdio>
#include<iostream>
#include<cmath>

using namespace std;

int main(){
    long long n;
    cin>>n;
    while(n--){
        int i;
        long long m,d,k;
        cin>>m;
        d = sqrt(m);
        k = sqrt(d);
        for(i=2;i<k;i++){
            if(d%i==0){
                break;
            }
        }
        if(d*d==m&&i>k&&m>1){
            cout<<"YES"<<endl;
        }
        else{
            cout<<"NO"<<endl;
        }
    }
    return 0;
}