#include<cstdio>
#include<iostream>
#include<algorithm>
#include<math.h>

using namespace std;

int main(){
    long long n;
    cin>>n;
    while(n--){
        long long i;
        long long m,d;
        cin>>m;
        d = sqrt(m);
        for(i=2;i*i<=d;i++){
            if(m%i==0){
                break;
            }
        }
        if(d*d == m&&i>sqrt(d)&&m>1){
            cout<<"YES"<<endl;
        }
        else{
            cout<<"NO"<<endl;
        }
    }
    return 0;
}