#include<iostream>
#include<cmath>
using namespace std;
int main(){
    int n;
    cin >> n;
    while(n--)
    {
        long long x;
        cin >> x;
        long long  d = sqrt(x);
        int i;
        for (i = 2;i * i<= d; i++){
            if (d % i == 0){
                break;
            }
        }
        if (d * d == x && i * i > d && x > 1){
            cout << "YES\n";
        }
        else{
            cout << "NO\n";
        }
    }
    return 0;
}