#include<stdio.h>

int main(){
    int n,i,j,k,a[100000],c=0;
    scanf("%d %d",&n,&k);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }

    for(j=0;j<n;j++){
        if(a[j]>=a[k]&& a[j] !=0){
            c++;
        }
    }
    printf("%d\n",c);

    return 0;
}