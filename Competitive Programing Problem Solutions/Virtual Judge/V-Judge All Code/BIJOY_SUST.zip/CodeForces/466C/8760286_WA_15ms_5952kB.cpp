#include<iostream>
#include<cstdio>

long long ara[500005],n,i,x,n_ways=0,t=0;
int main(){

    scanf("%lld",&n);
    for(i=1;i<=n;i++){
        scanf("%lld",&x);
        if(i==1){
            ara[i] = x;
        }
        else{
            ara[i] = ara[i-1] + x;
        }
    }
    if(ara[n]%3==0){
        long long u = ara[n]/3;
        long long v = 2*u;
        for(i=1;i<n;i++){
            if(ara[i] == u){
                t++;
            }
            if(ara[i] == v){
                n_ways += t;
            }
        }
    }

    printf("%lld\n",n_ways);

    return 0;
}