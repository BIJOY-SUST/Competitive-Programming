#include<bits/stdc++.h>
using namespace std;
int main(){
    int c=0,sum,len;
    string s;
    cin>>s;
    sum = atoi(s.c_str());
    len = s.length();
    for(int i=0;i<len;i++){
        if(s[i]=='4'||s[i]=='7') c++;
    }
    if(c==len) cout<<"YES"<<endl;
    else if(sum%47==0) cout<<"YES"<<endl;
    else if(sum%4==0||sum%7==0) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
    return 0;
}
