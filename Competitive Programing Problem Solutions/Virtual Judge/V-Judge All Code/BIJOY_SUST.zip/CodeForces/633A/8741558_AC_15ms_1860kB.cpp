#include<stdio.h>
int main()
{
    int x, y, z, i, j;
    scanf("%d%d%d", &x, &y, &z);
    for(i=0;;i++)
    {
        for(j=0;;j++)
        {
            if(x*i+y*j==z)
            {
                printf("Yes\n");
                return 0;
            }
            else if(x*i+y*j>z)
            {
                break;
            }
        }
        if(x*i>z)
        {
            printf("No\n");
            return 0;
        }
    }
    return 0;
}