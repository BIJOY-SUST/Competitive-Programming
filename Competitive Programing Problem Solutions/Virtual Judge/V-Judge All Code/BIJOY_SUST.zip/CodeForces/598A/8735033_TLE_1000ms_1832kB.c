#include<stdio.h>
#include<math.h>
int main(){
    long long int i,j,k,n,t,sum;
    scanf("%lld",&t);
    while(t--){
        sum = 0;
        scanf("%lld",&n);
        sum = n*(n+1)/2;
        for(j=1,k=0;j<=n;j++){
            if((long long int)pow(2,k)==j){
                sum = sum -2*j;
                k++;
            }
        }
        printf("%lld\n",sum);
    }
    return 0;
}