#include<bits/stdc++.h>
using namespace std;
int main(){
    int a=0,b=0,c=0;
    char s;
    while(s=getchar()){
        if(s=='1'){
            a++;
        }
        else if(s=='2'){
            b++;
        }
        else if(s=='3'){
            c++;
        }
        else if(s=='\n'){
            break;
        }
    }
    bool flag=true;
    for(int i=0;i<a;i++){
        if(flag==true){
            cout<<"1";
            flag=false;
        }
        else{
            cout<<"+1";
        }
    }
    for(int i=0;i<b;i++){
        if(flag==true){
            cout<<"2";
            flag=false;
        }
        else{
            cout<<"+2";
        }
    }
    for(int i=0;i<c;i++){
        if(flag==true){
            cout<<"3";
            flag=false;
        }
        else{
            cout<<"+3";
        }
    }
    cout<<endl;
    return 0;
}
