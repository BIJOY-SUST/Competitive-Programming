#include<bits/stdc++.h>
int main()
{
    int a,b,c,n;
    scanf("%d",&n);
    if(n<2)
    {
        printf("-1");
    }
    else
    {
        while(n--)
        printf("%d ",n);
    }
    return 0;
}
