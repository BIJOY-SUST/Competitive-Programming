#include<bits/stdc++.h>
int main()
{
    int a,b,c,n;
    scanf("%d",&n);
    if(n<=2)
    {
        printf("-1");
    }
    else
    {
       for(b=n-1;b>0;b--)
       {
        printf("%d ",b);
       }

    printf("%d\n",b);
    }
    return 0;
}
