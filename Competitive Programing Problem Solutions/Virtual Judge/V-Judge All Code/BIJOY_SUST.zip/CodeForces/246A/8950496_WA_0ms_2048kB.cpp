#include<bits/stdc++.h>
using namespace std;
int main()
{
    int b,n;
    cin>>n;
    if(n<=2){
        cout<<-1<<endl;
    }
    else{
       for(b=n-1;b>0;b--){
        cout<<b<<" ";
        }
        cout<<b<<endl;
    }
    return 0;
}