#include<bits/stdc++.h>
using namespace std;
int main(){
    char s[101],ss[101];
    while(1){
        scanf("%s",s);
        scanf("%s",ss);
        int l=strlen(s);
        int ll=strlen(ss);
        for(int i=0;i<l;i++){
            s[i]=tolower(s[i]);
        }
        for(int i=0;i<ll;i++){
            ss[i]=tolower(ss[i]);
        }

        if(l==0&&ll==0) break;
        if(strcmp(s,ss)==0)
        cout<<"0"<<endl;
       else if(strcmp(s,ss)<0)
        cout<<"-1"<<endl;
       else if(strcmp(s,ss)>0)
        cout<<"1"<<endl;


    }
    return 0;
}

