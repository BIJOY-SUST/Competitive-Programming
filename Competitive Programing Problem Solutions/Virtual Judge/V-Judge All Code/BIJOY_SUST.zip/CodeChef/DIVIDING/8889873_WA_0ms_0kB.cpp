#include<bits/stdc++.h>
#include<iostream>
using namespace std;

int main(){
 	long long N,m=0,n;
 	for(long long i=0;i<N;i++){
 		  cin>>n;
 		  m=m+n;
    }
    long s= N*(N+1)/2;
    if(m==s){
    	cout<<"YES"<<endl;
    }
    else{
    	cout<<"NO"<<endl;
    }
    
    return 0;
}