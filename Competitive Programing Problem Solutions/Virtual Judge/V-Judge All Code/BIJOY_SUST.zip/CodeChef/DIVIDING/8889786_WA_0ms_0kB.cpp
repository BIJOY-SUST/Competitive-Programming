#include<bits/stdc++.h>
using namespace std;
int main(){
 	long long  N,m=0;
 	string C;
        cin>>N;
 	for(int i=0;i<N;i++){
 		  cin>>C[i];
 		  m=m+C[i];
    }
    int s= N*(N+1)/2;
    if(m==s){
    	cout<<"YES"<<endl;
    }
    else{
    	cout<<"NO"<<endl;
    }
    
    return 0;
}
    	
