#include<bits/stdc++.h>

using namespace std;

int main(){
    int T;
    cin>>T;
    while(T--){
        long long N,i,j,c=1,a[100001],b[100001];
        memset(b,0,100001);
        cin>>N;
        for(i=0;i<N;i++){
            cin>>a[i];
        }
        for(i=0;i<N;i++){
            for(int j=0;j<N;j++)
            {
                while(a[i]!=0 && a[i]==a[j])
                {
                   c++;
                   a[i]=0;
                }
            }
        }
        cout<<c<<endl;
    }

    return 0;
}
