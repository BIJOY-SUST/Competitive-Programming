#include<bits/stdc++.h>
#include<cstring>

using namespace std;
class student{
public:
    string name;
    int Reg;
    double CGPA;
};
int main(){
    student x[5];
    for(int i=0;i<5;i++){
        cin>>x[i].name>>x[i].Reg>>x[i].CGPA;
    }
    for (int i = 1; i < 5; i++){
      for (int j = 0; j <5 - i; j++) {
         if(x[j].CGPA>x[j+1].CGPA == 1) {
            double temp = x[j].CGPA;
            x[j].CGPA = x[j+1].CGPA;
            x[j+1].CGPA =temp;
            string tt = x[j].name;
            x[j].name = x[j+1].name;
            x[j+1].name =tt;
            int ttt = x[j].Reg;
            x[j].Reg = x[j+1].Reg;
            x[j+1].Reg =ttt;

         }
      }
    }
    for(int j=0;j<5;j++){
        cout<<x[j].name<<" "<<x[j].Reg<<" "<<x[j].CGPA<<endl;
    }

    return 0;
}
