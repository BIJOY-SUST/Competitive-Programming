#include<bits/stdc++.h>

using namespace std;

int main(){
    int T,N;
    cin>>T;
    while(T--){
        int c=0;
        cin>>N;
        int a[100000];
        int b[100000]={};
        for(int i=0;i<N;i++){
            cin>>a[i];
        }
        for(int i=0;i<N;i++){
            if(!b[a[i]]){
                c++;
                b[a[i]]=1;
            }
        }
        cout<<c<<endl;
    }

    return 0;
}