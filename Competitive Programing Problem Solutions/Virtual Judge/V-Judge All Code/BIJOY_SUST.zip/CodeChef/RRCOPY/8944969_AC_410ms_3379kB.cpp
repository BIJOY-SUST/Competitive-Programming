#include<bits/stdc++.h>
using namespace std;
int main(){
    int T;
    cin>>T;
    while(T--){
        long long N,i,j,c=1;
        cin>>N;
        int a[100001];
        //int b[100000]={};
        for(i=0;i<N;i++){
            cin>>a[i];
        }
        sort(a,a+N);
        for(int i=1;i<N;i++)
        {
            if(a[i]!=a[i-1])
            {
                c++;
            }
        }
//        for(j=0;j<N;j++){
//            if(!b[a[j]]){
//                c++;
//                b[a[j]]=1;
//            }
//        }
        cout<<c<<endl;
    }

    return 0;
}
