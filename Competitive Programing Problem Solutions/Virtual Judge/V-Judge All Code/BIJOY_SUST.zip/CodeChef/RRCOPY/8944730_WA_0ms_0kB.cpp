#include<bits/stdc++.h>
#include<cstring>

using namespace std;
class student{
public:
    string name;
    int Reg;
    double CGPA;
};
bool sot(student a,student b){
    return a.CGPA<b.CGPA;
}
int main(){
    student x[109],y[109];
    for(int i=0;i<5;i++){
        cin>>x[i].name>>x[i].Reg>>x[i].CGPA;
    }
    sort(x,x+5,sot);
    /*for (int i = 1; i < 5; i++){
      for (int j = 0; j <5 - i; j++) {
         if(x[j].CGPA>x[j+1].CGPA == 1) {
            y[j] = x[j];
            x[j] = x[j+1];
            x[j+1]=y[j];
            /*string tt = x[j].name;
            x[j].name = x[j+1].name;
            x[j+1].name =tt;
            int ttt = x[j].Reg;
            x[j].Reg = x[j+1].Reg;
            x[j+1].Reg =ttt;

         }
      }
    }*/
    for(int j=0;j<5;j++){
        cout<<x[j].name<<" "<<x[j].Reg<<" "<<x[j].CGPA<<endl;
    }

    return 0;
}

