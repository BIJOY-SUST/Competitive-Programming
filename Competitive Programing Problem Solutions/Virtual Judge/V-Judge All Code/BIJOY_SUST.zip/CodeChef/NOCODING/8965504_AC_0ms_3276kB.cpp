#include<bits/stdc++.h>
using namespace std;

int main(){
    int T;
    cin>>T;
    while(T--){
        string s;
        cin>>s;
        int no=0;
        for(int i=0;i<s.length()-1;i++){
            no=no+((s[i+1]-s[i]+26)%26);
        }
        no =no+s.length()+1;
        if(no<=s.length()*11){
            cout<<"YES"<<endl;
        }
        else{
            cout<<"NO"<<endl;
        }
    }
    return 0;
}