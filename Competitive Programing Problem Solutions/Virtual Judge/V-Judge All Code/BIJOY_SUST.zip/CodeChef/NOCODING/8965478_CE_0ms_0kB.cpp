#include<bits/stdc++.h>
using namespace std;

int main(){
    int T;
    cin>>T;
    while(T--){
        string s;
        cin>>s;
        int no=2;
        for(int i=0;i<s.length()-1;i++){
            //cout<<"A= "<<str[i]-str[i+1]<<" ";
            //cout<<"B= "<<((str[i]-str[i+1]+26)%26) <<" ";
            no=no+((str[i]-str[i+1]+26)%26) ;
            //cout<<s<<endl;
        }
        if(no<=l*11){
            cout<<"YES"<<endl;
        }
        else{
            cout<<"NO"<endl;
        }
    }
    return 0;
}