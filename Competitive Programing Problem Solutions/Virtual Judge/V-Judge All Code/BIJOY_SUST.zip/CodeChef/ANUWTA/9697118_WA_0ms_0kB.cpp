#include<stdio.h>
#include<math.h>
int main(){
    long int t,n,i;
    scanf("%ld",&t);
    for(i=1;i<=t;i++){
        scanf("%ld",&n);
        long int ans = (n*(n+1)*(2*n+1))/6;
        printf("%ld\n",ans);
    }
    return 0;
}
