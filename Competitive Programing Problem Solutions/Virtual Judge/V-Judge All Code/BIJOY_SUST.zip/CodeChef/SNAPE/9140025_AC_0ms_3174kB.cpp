#include<bits/stdc++.h>
using namespace std;
int main(){
    int B,L;
    int T;
    double rmin,rmax;
    cin>>T;
    for(int i=0;i<T;i++){
        cin>>B>>L;
        rmin = sqrt(L*L - B*B);
        rmax = sqrt(L*L + B*B);
        cout<<rmin<<" "<<rmax<<endl;
    }
    return 0;
}
