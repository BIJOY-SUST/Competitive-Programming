#include<stdio.h>
int main(){
    int  a,b;
    while(scanf("%d %d",&a,&b)==2){
        int  s = a-b;
    printf("%d\n",s);
    }
    return 0;
}
