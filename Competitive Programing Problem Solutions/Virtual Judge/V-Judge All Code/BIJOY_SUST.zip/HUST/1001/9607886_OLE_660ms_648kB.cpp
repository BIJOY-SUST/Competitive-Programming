#include<bits/stdc++.h>
using namespace std;
int main(){
    //ios_base::sync_with_stdio(false);
    //cin.tie(NULL);

    while(1){
    int n;
    cin>>n;
    cout<<n-1<<" "<<"1"<<"\n";
    }
    return 0;
}
