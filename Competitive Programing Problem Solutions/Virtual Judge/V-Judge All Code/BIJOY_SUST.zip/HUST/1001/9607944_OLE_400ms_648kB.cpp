#include<bits/stdc++.h>
using namespace std;
int main(){
    //ios_base::sync_with_stdio(false);
    //cin.tie(NULL);

    while(1){
    int n;
    cin>>n;
    int b=n-1;
    int c=n-n+1;
    printf("%d %d\n",b,c);
    //cout<<b<<" "<<c<<"\n";
    }
    return 0;
}
